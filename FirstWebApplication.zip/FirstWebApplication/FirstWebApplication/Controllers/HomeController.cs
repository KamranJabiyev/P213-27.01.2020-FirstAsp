﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FirstWebApplication.Controllers
{
    public class HomeController:Controller
    {
        public ViewResult Index()
        {
            //return "Index sehifesi";
            //ViewResult view = new ViewResult();
            //view.ViewName = "Index";
            //return View("Index");
            return View();
        }

        public ViewResult About()
        {
            return View();
        }

        
    }
}
